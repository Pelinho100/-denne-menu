DENNÉ MENU v9 – verzia určená pre iPhone Safari

Prečo sa predchádzajúca verzia zobrazila zle:
iPhone otvoril index.html v Rýchlom náhľade (Quick Look), nie ako normálnu webovú aplikáciu.
V Rýchlom náhľade sa dynamický JavaScript nemusí spustiť, preto sa zobrazil iba statický vrch stránky.

Správne použitie:
1. Rozbaľ tento ZIP.
2. Presuň celý priečinok denne_menu_v9 do:
   Súbory > Na mojom iPhone > a-Shell
3. Otvor a-Shell.
4. Prejdi do priečinka denne_menu_v9.
5. Spusti:
   python3 -m http.server 8080
6. Otvor Safari a zadaj:
   http://127.0.0.1:8080
7. Potom môžeš v Safari dať Zdieľať > Pridať na plochu.

Aplikácia:
- Pondelok až Piatok
- každý deň 2 polievky + 5 hlavných jedál
- pridať/odobrať položku
- vyhľadávací výber jedál
- databáza: Hlavné jedlo / Polievka / Príloha
- meniť dátum, názov, cenu, gramáž, alergény
- tlač A4
